# Panther Admin

Proyecto SwiftUI para iPhone (iOS 16 o posterior). Permite gestionar keys, patches, cuentas de revendedores, créditos y precios por cuenta.

## Compilar en GitHub

En **Actions**, abre **Compilar Panther Admin y descargar IPA**. Ese flujo compila el proyecto de esta carpeta y publica el artefacto `Panther-Keygarden-Admin-unsigned`. Descarga y descomprime el artefacto para obtener la IPA. La IPA requiere una firma válida antes de instalarla.

Para compilar localmente desde esta carpeta, ejecuta `xcodegen generate` y abre `PantherKeygarden.xcodeproj` en Xcode.

## Conectar el servidor

En Ajustes, configura la URL HTTPS de Panther Keygarden y el token de administrador. Para eliminar cuentas, guardar precios individuales y otorgar permisos permanentes, utiliza el servidor Panther Keygarden 1.1.0 o posterior.
